using UnityEngine;
using System.IO;
using System.Collections.Generic;

public class DialogueManager : MonoBehaviour
{
    private DialogueData currentDialogue;
    private string currentTaskId;

    public DialogueData LoadDialogue(string taskId)
    {
        string path = Path.Combine(Application.streamingAssetsPath, "Dialogues", taskId + ".json");
        if (!File.Exists(path))
        {
            Debug.LogError($"[DialogueManager] Dialogue file not found: {path}");
            return null;
        }

        string json = File.ReadAllText(path);
        currentDialogue = JsonUtility.FromJson<DialogueData>(json);
        currentTaskId = taskId;
        return currentDialogue;
    }

    public DialogueEntry GetRandomEntry()
    {
        if (currentDialogue == null || currentDialogue.dialogues.Count == 0)
            return null;

        int index = Random.Range(0, currentDialogue.dialogues.Count);
        return currentDialogue.dialogues[index];
    }

    public string HandlePlayerAnswer(PlayerOption option)
    {
        Debug.Log($"[DialogueManager] Player selected: {option.id}");
        return option.id;
    }
}
