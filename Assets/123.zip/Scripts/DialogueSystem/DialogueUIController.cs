﻿using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections.Generic;

public class DialogueUIController : MonoBehaviour
{
    [SerializeField] private DialogueManager dialogueManager;
    [SerializeField] private TextMeshProUGUI npcText;

    [Header("Left (Positive)")]
    [SerializeField] private Button[] leftButtons;

    [Header("Right (Negative)")]
    [SerializeField] private Button[] rightButtons;

    private DialogueEntry currentEntry;

    public void ShowDialogueForTask(string taskId)
    {
        var data = dialogueManager.LoadDialogue(taskId);
        if (data == null) return;

        currentEntry = dialogueManager.GetRandomEntry();
        npcText.text = currentEntry.npcVariants[Random.Range(0, currentEntry.npcVariants.Count)];

        // Отдельные списки для типов
        var positives = new List<PlayerOption>();
        var negatives = new List<PlayerOption>();

        foreach (var option in currentEntry.playerOptions)
        {
            if (option.type.ToLower().Contains("pos")) positives.Add(option);
            else negatives.Add(option);
        }

        SetupButtons(leftButtons, positives);
        SetupButtons(rightButtons, negatives);
    }

    private void SetupButtons(Button[] buttons, List<PlayerOption> options)
    {
        for (int i = 0; i < buttons.Length; i++)
        {
            if (i < options.Count)
            {
                var option = options[i];
                string text = option.variants[Random.Range(0, option.variants.Count)];

                buttons[i].gameObject.SetActive(true);
                var tmp = buttons[i].GetComponentInChildren<TextMeshProUGUI>();
                tmp.text = text;
                tmp.fontSize = 36; // увеличенный шрифт
                tmp.enableAutoSizing = false;

                buttons[i].onClick.RemoveAllListeners();
                buttons[i].onClick.AddListener(() =>
                {
                    string id = dialogueManager.HandlePlayerAnswer(option);
                    OnAnswerSelected(id);
                });
            }
            else buttons[i].gameObject.SetActive(false);
        }
    }

    private void OnAnswerSelected(string answerId)
    {
        Debug.Log($"Выбран ответ: {answerId}");
    }
}
