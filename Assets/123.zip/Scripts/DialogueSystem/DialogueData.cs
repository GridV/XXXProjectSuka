﻿using System.Collections.Generic;

[System.Serializable]
public class DialogueData
{
    public string taskId;
    public List<DialogueEntry> dialogues;
}

[System.Serializable]
public class DialogueEntry
{
    public List<string> npcVariants;
    public List<PlayerOption> playerOptions;
}

[System.Serializable]
public class PlayerOption
{
    public string id;
    public List<string> variants;
    public string type; // Positive, Negative, Neutral и т.д.
}
